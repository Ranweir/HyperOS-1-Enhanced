#!/usr/bin/env bash
# Usage: fix_rom.sh <rom.zip> <workdir>
# Supports: system/vendor/product/system_ext/odm as *.new.dat.br, *.new.dat or *.img (ext4 only)
set -euo pipefail

ROM_ZIP="$(realpath "$1")"
WORK="$(realpath -m "${2:-work}")"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOLS="$ROOT/tools"
CFG="$ROOT/config"
ROM="$WORK/rom"; MNT="$WORK/mnt"; REPORT="$WORK/report.txt"

mkdir -p "$ROM" "$MNT"; : > "$REPORT"
log() { echo "$*" | tee -a "$REPORT"; }

set_prop() {  # file key value
  local f="$1" k="$2" v="$3"
  sudo sed -i "/^${k//./\\.}=/d" "$f"
  if [ -n "$(sudo tail -c1 "$f")" ]; then echo | sudo tee -a "$f" >/dev/null; fi
  echo "$k=$v" | sudo tee -a "$f" >/dev/null
}

apply_props() {  # file configfile
  local f="$1" cfg="$2"
  [ -f "$f" ] || { log "  ! build.prop nahi mila: $f"; return; }
  while IFS= read -r line; do
    line="${line%%#*}"; line="$(echo "$line" | xargs || true)"
    [ -z "$line" ] && continue
    set_prop "$f" "${line%%=*}" "${line#*=}"
    log "  prop: $line"
  done < "$cfg"
}

find_prop() {  # build.prop path (system-as-root ya normal)
  if [ -f "$MNT/system/build.prop" ]; then echo "$MNT/system/build.prop"; else echo "$MNT/build.prop"; fi
}

debloat() {
  while IFS= read -r name; do
    name="${name%%#*}"; name="$(echo "$name" | xargs || true)"
    [ -z "$name" ] && continue
    while IFS= read -r d; do
      [ -n "$d" ] || continue
      sudo rm -rf "$d" && log "  removed: ${d#$MNT}"
    done < <(sudo find "$MNT" -maxdepth 5 -type d \( -path "*/app/$name" -o -path "*/priv-app/$name" \))
  done < "$CFG/debloat.txt"
}

diagnose_vendor() {
  log "  --- Bluetooth diagnostics (vendor) ---"
  sudo find "$MNT" -maxdepth 4 -iname "*bluetooth*audio*" | sed "s#$MNT#   #" | tee -a "$REPORT" || true
  for x in $(sudo find "$MNT" -maxdepth 3 -name "audio_policy*.xml" 2>/dev/null); do
    log "  $x"
    sudo grep -in "a2dp\|bluetooth" "$x" | head -20 | tee -a "$REPORT" || true
  done
}

unzip -q "$ROM_ZIP" -d "$ROM"
cd "$WORK"

for p in system vendor product system_ext odm; do
  fmt=""
  if   [ -f "$ROM/$p.new.dat.br" ]; then fmt="datbr"; brotli -d -f "$ROM/$p.new.dat.br" -o "$WORK/$p.new.dat"
  elif [ -f "$ROM/$p.new.dat"    ]; then fmt="dat";   cp "$ROM/$p.new.dat" "$WORK/$p.new.dat"
  elif [ -f "$ROM/$p.img"        ]; then fmt="img"
  else continue; fi

  log "=== $p ($fmt) ==="
  if [ "$fmt" = "img" ]; then
    cp "$ROM/$p.img" "$WORK/$p.img"
    if [ "$(xxd -l 4 -p "$WORK/$p.img")" = "3aff26ed" ]; then
      simg2img "$WORK/$p.img" "$WORK/$p.raw.img" && mv "$WORK/$p.raw.img" "$WORK/$p.img"
    fi
  else
    python3 "$TOOLS/sdat2img/sdat2img.py" "$ROM/$p.transfer.list" "$WORK/$p.new.dat" "$WORK/$p.img" >/dev/null
    rm -f "$WORK/$p.new.dat"
  fi

  if [ "$(xxd -s 1024 -l 4 -p "$WORK/$p.img")" = "e2e1f5e0" ]; then
    log "  ! $p EROFS hai, skip kiya (sirf ext4 supported)"; rm -f "$WORK/$p.img"; continue
  fi

  e2fsck -fy "$WORK/$p.img" >/dev/null 2>&1 || true
  e2fsck -fy -E unshare_blocks "$WORK/$p.img" >/dev/null 2>&1 || true
  sudo mount -o loop,rw "$WORK/$p.img" "$MNT"

  case "$p" in
    system)
      apply_props "$(find_prop)" "$CFG/props_system.txt"
      debloat ;;
    vendor)
      apply_props "$(find_prop)" "$CFG/props_vendor.txt"
      diagnose_vendor ;;
    product|system_ext)
      debloat ;;
  esac

  sync; sudo umount "$MNT"
  e2fsck -fy "$WORK/$p.img" >/dev/null 2>&1 || true

  case "$fmt" in
    datbr|dat)
      mkdir -p "$WORK/out_$p"
      python3 "$TOOLS/img2sdat/img2sdat.py" "$WORK/$p.img" -o "$WORK/out_$p" -v 4 -p "$p" >/dev/null
      cp "$WORK/out_$p/$p.transfer.list" "$WORK/out_$p/$p.patch.dat" "$ROM/"
      if [ "$fmt" = "datbr" ]; then
        brotli -q 5 -f "$WORK/out_$p/$p.new.dat" -o "$ROM/$p.new.dat.br"
      else
        cp "$WORK/out_$p/$p.new.dat" "$ROM/$p.new.dat"
      fi
      rm -rf "$WORK/out_$p" ;;
    img)
      cp "$WORK/$p.img" "$ROM/$p.img" ;;
  esac
  rm -f "$WORK/$p.img"
done

(cd "$ROM" && zip -qr -1 "$WORK/patched.zip" .)
log "Done: $WORK/patched.zip"
